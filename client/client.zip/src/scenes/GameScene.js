import Phaser from "phaser";
import { getSocket } from "../net/socket.js";
import { VoiceCaster } from "../voice/VoiceCaster.js";

const PHASE = Object.freeze({
  LOBBY: "LOBBY",
  PREROUND: "PREROUND",
  ROUND: "ROUND",
  END: "END",
});

// Fallback behavior (if a spell is missing behavior in spells.json)
const SPELL_BEHAVIOR_FALLBACK = Object.freeze({
  spark:    { speed: 580, lifetimeMs: 650, radius: 6,  count: 1, spreadDeg: 0  },
  wagalona: { speed: 400, lifetimeMs: 1100, radius: 12, count: 1, spreadDeg: 0  },
  zephyra:  { speed: 520, lifetimeMs: 850, radius: 7,  count: 2, spreadDeg: 12 },
  vortium:  { speed: 340, lifetimeMs: 1400, radius: 16, count: 1, spreadDeg: 0  },
});

const MAX_MANA = 100;
const MANA_REGEN_PER_SEC = 12;

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function getSpellMeta(scene, spellId) {
  const spell = scene.spellData?.[spellId] || {};
  const kind = String(spell.kind || (spellId === "shieldra" ? "shield" : "projectile")).toLowerCase();
  const behavior = spell.behavior || {};
  const color = Number.isFinite(spell.color) ? spell.color : null;
  const vfx = spell.vfx || {};
  return { spellId, spell, kind, behavior, color, vfx };
}

function prng(seed) {
  let t = seed >>> 0;
  return () => {
    t += 0x6D2B79F5;
    let x = Math.imul(t ^ (t >>> 15), 1 | t);
    x ^= x + Math.imul(x ^ (x >>> 7), 61 | x);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

// Simple Web Audio beep generator
function makeBeep(ctx, freq, dur, vol = 0.15, type = "sine") {
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
    osc.connect(gain).connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + dur);
  } catch {}
}

export class GameScene extends Phaser.Scene {
  constructor() {
    super("Game");
    this.clockOffsetMs = 0;
    this.phase = PHASE.LOBBY;
    this.phaseEndTime = null;
    this.playerId = null;
    this.roomCode = null;
    this.playersById = new Map();
    this.keywordToSpell = new Map();
    this.spellData = {};
    this.micOn = false;
    this.mana = MAX_MANA;
    this.lastCastTime = {};  // spellId -> timestamp
    this.audioCtx = null;

    // VFX / UI
    this.vfx = null;
    this.ui = null;
    this.gameOver = null;
    this.shieldSprite = null;
  }

  init(data) {
    this.roomCode = data?.roomCode;
    this.playerId = data?.playerId;
    this.loadout = data?.loadout || null;
  }

  preload() {
    // Characters / environment
    this.load.spritesheet("wizard-red", "/assets/wizard-idle.png", { frameWidth: 50, frameHeight: 81 });
    this.load.spritesheet("wizard-blue", "/assets/wizard-idle-blue.png", { frameWidth: 50, frameHeight: 81 });
    this.load.spritesheet("wand-cast", "/assets/wand-cast.png", { frameWidth: 113, frameHeight: 98 });
    this.load.image("arena-bg", "/assets/arena-bg.png");
    this.load.tilemapTiledJSON("arena-tmj", "/assets/arena.tmj");

    // Projectile art (optional)
    this.load.image("proj-spark", "/assets/proj-spark.png");
    this.load.image("proj-wagalona", "/assets/proj-wagalona.png");
    this.load.image("proj-zephyra", "/assets/proj-zephyra.png");

    // Drive UI assets
    this.load.image("ui-basic", "/assets/basic_ui.png");
    this.load.image("ui-sub", "/assets/Spell_sub_box.png");
    this.load.image("ui-hp-frame", "/assets/hp-frame.png");
    this.load.image("ui-mana-frame", "/assets/mana-frame.png");
    this.load.image("ui-hp-strip", "/assets/ui_HP.png");
    this.load.image("ui-hp-bar-big", "/assets/ui_HP_BAR.png");
  }

  async create(data) {
    this.roomCode = data?.roomCode;
    this.playerId = data?.playerId;
    this.loadout = data?.loadout || this.loadout || null;
    this.equipped = new Set((this.loadout?.length) ? this.loadout : ["spark","wagalona","zephyra"]);
    this.mana = MAX_MANA;
    this.lastCastTime = {};
    this.gameOver = { shown: false };

    // Load spell data
    try {
      const [spellsRes, keywordsRes] = await Promise.all([
        fetch("/data/spells.json"), fetch("/data/keywords.json"),
      ]);
      this.spellData = await spellsRes.json();
      const keywords = await keywordsRes.json();
      this.buildKeywordIndex(keywords);
    } catch (e) { console.warn("Failed to load spell data:", e); }

    // Audio context (user gesture required)
    this.input.once("pointerdown", () => {
      if (!this.audioCtx) this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    });
    this.input.keyboard?.once("keydown", () => {
      if (!this.audioCtx) this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    });

    const socket = getSocket();

    // Background
    if (this.textures.exists("arena-bg")) {
      this.add.image(320, 200, "arena-bg").setDisplaySize(640, 400);
    } else {
      this.add.rectangle(320, 200, 640, 400, 0x0f1723);
    }

    // Animations
    if (!this.anims.exists("wiz-red-idle")) {
      this.anims.create({ key: "wiz-red-idle", frames: this.anims.generateFrameNumbers("wizard-red", { start: 0, end: 1 }), frameRate: 3, repeat: -1 });
    }
    if (!this.anims.exists("wiz-blue-idle")) {
      this.anims.create({ key: "wiz-blue-idle", frames: this.anims.generateFrameNumbers("wizard-blue", { start: 0, end: 1 }), frameRate: 3, repeat: -1 });
    }

    // Physics
    this.physics.world.setBounds(40, 80, 560, 280);
    this.playerGroup = this.physics.add.group();
    this.projectiles = this.physics.add.group();

    // VFX + HUD
    this.initVFX();
    this.initHud();
    this.initGameOverOverlay();

    // Input
    const kb = this.input?.keyboard;
    if (kb) {
      this.cursors = kb.createCursorKeys();
      this.keyR = kb.addKey(Phaser.Input.Keyboard.KeyCodes.R);
      this.keyM = kb.addKey(Phaser.Input.Keyboard.KeyCodes.M);
      this.key1 = kb.addKey(Phaser.Input.Keyboard.KeyCodes.ONE);
      this.key2 = kb.addKey(Phaser.Input.Keyboard.KeyCodes.TWO);
      this.key3 = kb.addKey(Phaser.Input.Keyboard.KeyCodes.THREE);
      this.keyN = kb.addKey(Phaser.Input.Keyboard.KeyCodes.N);
      this.keyB = kb.addKey(Phaser.Input.Keyboard.KeyCodes.B);
    } else {
      console.warn("[GameScene] Keyboard input unavailable; disabling keyboard controls.");
      this.cursors = null;
      this.keyR = this.keyM = this.key1 = this.key2 = this.key3 = this.keyN = this.keyB = null;
    }

    // Socket handlers
    socket.on("room:state", (st) => {
      this.phase = st.phase;
      this.phaseEndTime = st.phaseEndTime;
      this.updatePlayers(st.players);
      this.updateHudFromPlayers(st.players);
      if (st.phase !== PHASE.END) this.hideGameOver();
    });

    socket.on("phase:start", ({ phase, durationMs, serverTime }) => {
      this.phase = phase;
      this.clockOffsetMs = (serverTime ?? Date.now()) - Date.now();
      this.phaseEndTime = durationMs ? (serverTime + durationMs) : null;

      if (phase === PHASE.ROUND) {
        this.mana = MAX_MANA;
        makeBeep(this.audioCtx, 880, 0.15, 0.1);
        setTimeout(() => makeBeep(this.audioCtx, 1100, 0.2, 0.12), 150);
      }
      if (phase === PHASE.PREROUND) makeBeep(this.audioCtx, 440, 0.3, 0.08);
    });

    socket.on("spell:event", (evt) => {
      this.spawnSpell(evt);

      const meta = this.spellData?.[evt.spellId] || {};
      const base = meta.kind === "heal" ? 740 : (meta.kind === "block" ? 420 : (evt.spellId === "vortium" ? 200 : 520));
      makeBeep(this.audioCtx, base, 0.12, 0.08, evt.spellId === "vortium" ? "sawtooth" : "sine");
    });

    socket.on("status:event", (evt) => {
      if (evt.type === "stun") {
        const target = this.playersById.get(evt.targetId);
        if (target?.sprite) {
          const star = this.add.text(target.sprite.x, target.sprite.y - 90, "★", { fontSize: "18px", color: "#ffd54f" }).setOrigin(0.5).setDepth(1200);
          this.tweens.add({ targets: star, y: star.y - 12, alpha: 0, duration: Math.min(900, evt.ms || 900), ease: "Quad.easeOut", onComplete: () => star.destroy() });
        }
      }
    });

    socket.on("hit:event", (evt) => {
      const caster = this.playersById.get(evt.casterId);
      const target = this.playersById.get(evt.targetId);

      // Subtitle + VFX
      if (evt.blocked) {
        this.setSubtitle(`${caster?.name || "?"} hit ${target?.name || "?"} with ${evt.spellId} (BLOCKED)`);
      } else {
        this.setSubtitle(`${caster?.name || "?"} hit ${target?.name || "?"} with ${evt.spellId} (-${evt.damage})`);
      }

      const targetObj = this.playersById.get(evt.targetId);
      const spellId = String(evt.spellId || "").toLowerCase();
      const { color, vfx, kind, behavior } = getSpellMeta(this, spellId);
      const tint = color ?? 0xffffff;

      // Gas cloud: spawn once on first tick
      if (kind === "status" && evt.tickIndex === 0 && (vfx?.area || behavior?.durationMs || spellId === "gas_condensation")) {
        const radius = Number(behavior?.radius ?? this.spellData?.[spellId]?.radius ?? 110);
        const duration = Number(behavior?.durationMs ?? this.spellData?.[spellId]?.durationMs ?? 2800);
        if (targetObj?.sprite) this.spawnGasCloud(targetObj.sprite.x, targetObj.sprite.y, tint, radius, duration);
      }

      if (targetObj?.sprite) {
        // Flash on hit (not when blocked)
        if (!evt.blocked) {
          targetObj.sprite.setTint(0xff4040);
          this.time.delayedCall(110, () => { if (targetObj.sprite?.active) targetObj.sprite.clearTint(); });
        }

        // Impact particles
        if (evt.blocked) {
          this.spawnBlockedSpark(targetObj.sprite.x, targetObj.sprite.y, tint);
        } else {
          const power = Number(vfx?.shake ?? 0) || clamp(Number(evt.damage ?? 0) / 6, 1, 8);
          this.spawnImpactBurst(targetObj.sprite.x, targetObj.sprite.y, tint, power);
        }
      }

      // Camera feedback
      const isMe = evt.targetId === this.playerId;
      if (isMe && !evt.blocked) {
        const intensity = clamp((Number(evt.damage ?? 0) / 30) * 0.02, 0.006, 0.02);
        this.cameras.main.shake(160, intensity);
        this.cameras.main.flash(80, 255, 70, 70, true);
        makeBeep(this.audioCtx, 150, 0.22, 0.14, "sawtooth");
      } else if (!evt.blocked) {
        makeBeep(this.audioCtx, 500, 0.08, 0.06);
      } else {
        makeBeep(this.audioCtx, 260, 0.08, 0.05, "triangle");
      }
    });

    socket.on("heal:event", (evt) => {
      const caster = this.playersById.get(evt.casterId);
      this.setSubtitle(`${caster?.name || "?"} cast ${evt.spellId} (+${evt.heal})`);
      const cObj = this.playersById.get(evt.casterId);
      if (cObj?.sprite) this.spawnHealBurst(cObj.sprite.x, cObj.sprite.y, 0x66ccff, Number(evt.heal ?? 10));
      makeBeep(this.audioCtx, 760, 0.10, 0.06, "sine");
    });

    socket.on("match:end", ({ winnerId }) => {
      this.phase = PHASE.END;
      this.phaseEndTime = null;
      this.showGameOver(winnerId);

      const isWin = winnerId === this.playerId;
      if (isWin) {
        makeBeep(this.audioCtx, 523, 0.15, 0.1);
        setTimeout(() => makeBeep(this.audioCtx, 659, 0.15, 0.1), 150);
        setTimeout(() => makeBeep(this.audioCtx, 784, 0.3, 0.12), 300);
      } else {
        makeBeep(this.audioCtx, 300, 0.4, 0.1, "sawtooth");
      }
    });

    // Voice
    this.voice = new VoiceCaster(
      ({ raw, normalized }) => this.onVoicePhrase(raw, normalized),
      (err) => this.setSubtitle(`Mic error: ${err}`)
    );

    this.micOn = false;
    this.ui?.micText?.setText("🎙 OFF");

    const lo = Array.from(this.equipped || []);
    this.setSubtitle(`Loadout: ${lo.map((s,i) => `${i+1}=${s}`).join(", ")} · R=Ready M=Mic`);

    // Pose sync
    this.poseTimer = this.time.addEvent({ delay: 50, loop: true, callback: () => this.sendPoseIfNeeded() });

    this.events.once("shutdown", () => {
      try { this.voice?.stop(); } catch {}
      this.vfx?.manager?.destroy();
      this.ui?.root?.destroy(true);
      this.gameOver?.root?.destroy(true);
    });
  }

  // ───────────────────────── VFX ─────────────────────────
  initVFX() {
    // Create a tiny pixel texture for particles (if missing)
    if (!this.textures.exists("_px")) {
      const g = this.make.graphics({ add: false });
      g.fillStyle(0xffffff, 1);
      g.fillRect(0, 0, 2, 2);
      g.generateTexture("_px", 2, 2);
      g.destroy();
    }

    const manager = this.add.particles(0, 0, "_px").setDepth(950);
    this.vfx = { manager };
  }

  spawnImpactBurst(x, y, tint, power = 3) {
    if (!this.vfx?.manager) return;
    const qty = clamp(Math.floor(10 + power * 6), 10, 70);

    const em = this.vfx.manager.createEmitter({
      x, y,
      quantity: qty,
      lifespan: { min: 220, max: 420 },
      speed: { min: 40 + power * 10, max: 120 + power * 24 },
      angle: { min: 0, max: 360 },
      scale: { start: 2.2, end: 0 },
      alpha: { start: 0.9, end: 0 },
      tint,
      blendMode: "ADD",
    });

    this.time.delayedCall(60, () => em.stop());
    this.time.delayedCall(520, () => { try { this.vfx.manager.removeEmitter(em); } catch {} });
  }

  spawnBlockedSpark(x, y, tint) {
    if (!this.vfx?.manager) return;
    const em = this.vfx.manager.createEmitter({
      x, y,
      quantity: 14,
      lifespan: { min: 160, max: 260 },
      speed: { min: 40, max: 120 },
      angle: { min: 0, max: 360 },
      scale: { start: 1.8, end: 0 },
      alpha: { start: 0.75, end: 0 },
      tint: 0x99ffdd,
      blendMode: "ADD",
    });
    this.time.delayedCall(40, () => em.stop());
    this.time.delayedCall(350, () => { try { this.vfx.manager.removeEmitter(em); } catch {} });
  }

  spawnHealBurst(x, y, tint, amount = 10) {
    if (!this.vfx?.manager) return;
    const power = clamp(amount / 10, 1, 6);
    const qty = clamp(Math.floor(14 + power * 8), 14, 70);

    const em = this.vfx.manager.createEmitter({
      x, y,
      quantity: qty,
      lifespan: { min: 300, max: 650 },
      speed: { min: 20, max: 80 + power * 20 },
      angle: { min: 0, max: 360 },
      scale: { start: 2.0, end: 0 },
      alpha: { start: 0.6, end: 0 },
      tint,
      blendMode: "ADD",
    });

    // soft ring
    const ring = this.add.circle(x, y, 10, tint, 0.12).setStrokeStyle(2, tint, 0.65).setDepth(960);
    this.tweens.add({ targets: ring, scale: 4.2, alpha: 0, duration: 520, ease: "Cubic.easeOut", onComplete: () => ring.destroy() });

    this.time.delayedCall(80, () => em.stop());
    this.time.delayedCall(800, () => { try { this.vfx.manager.removeEmitter(em); } catch {} });
  }

  spawnGasCloud(x, y, tint, radius = 110, durationMs = 3800) {
    if (!this.vfx?.manager) return;

    // Soft area ring
    const ring = this.add.circle(x, y, radius * 0.55, tint, 0.06).setStrokeStyle(2, tint, 0.25).setDepth(920);
    this.tweens.add({
      targets: ring,
      alpha: { from: 0.22, to: 0.05 },
      duration: 900,
      yoyo: true,
      repeat: Math.max(0, Math.floor(durationMs / 900) - 1),
      onComplete: () => ring.destroy(),
    });

    const circle = new Phaser.Geom.Circle(0, 0, radius);
    const em = this.vfx.manager.createEmitter({
      x, y,
      lifespan: { min: 700, max: 1400 },
      speed: { min: 5, max: 22 },
      angle: { min: 0, max: 360 },
      scale: { start: 6.0, end: 10.0 },
      alpha: { start: 0.14, end: 0 },
      tint,
      blendMode: "NORMAL",
      frequency: 70,
      emitZone: { type: "random", source: circle },
    });

    this.time.delayedCall(durationMs, () => {
      em.stop();
      this.time.delayedCall(1500, () => { try { this.vfx.manager.removeEmitter(em); } catch {} });
    });
  }

  // ───────────────────────── HUD / UI ─────────────────────────
  initHud() {
    const root = this.add.container(0, 0).setDepth(1100).setScrollFactor(0);

    // Decorative strip
    if (this.textures.exists("ui-hp-strip")) {
      const strip = this.add.image(10, 6, "ui-hp-strip").setOrigin(0, 0).setScale(0.9);
      root.add(strip);
    }

    // Top texts
    const roomText = this.add.text(12, 10, `Room: ${this.roomCode || ""}`, { fontSize: "11px", color: "#b6c2d9" });
    const phaseText = this.add.text(12, 26, `Phase: ${this.phase}`, { fontSize: "11px", color: "#b6c2d9" });
    root.add(roomText);
    root.add(phaseText);

    // HP bars
    const hpFrameL = this.add.image(12, 48, "ui-hp-frame").setOrigin(0, 0);
    const hpFillL = this.add.rectangle(18, 60, 188, 12, 0x4ade80, 1).setOrigin(0, 0.5);
    const hpNameL = this.add.text(12, 38, "", { fontSize: "10px", color: "#6ee7ff" });

    const hpFrameR = this.add.image(628, 48, "ui-hp-frame").setOrigin(1, 0).setFlipX(true);
    const hpFillR = this.add.rectangle(622, 60, 188, 12, 0xfb923c, 1).setOrigin(1, 0.5);
    const hpNameR = this.add.text(628, 38, "", { fontSize: "10px", color: "#ffb86e" }).setOrigin(1, 0);

    // Mana (local only)
    const manaFrame = this.add.image(12, 74, "ui-mana-frame").setOrigin(0, 0);
    const manaFill = this.add.rectangle(18, 80, 188, 6, 0x818cf8, 1).setOrigin(0, 0.5);
    const manaText = this.add.text(12, 88, "MP 100", { fontSize: "10px", color: "#a5b4fc" });

    root.add([hpFrameL, hpFillL, hpNameL, hpFrameR, hpFillR, hpNameR, manaFrame, manaFill, manaText]);

    // Spell slots
    const slots = [];
    const slotY = 300;
    const slotStartX = 320 - 90;
    const slotGap = 70;

    for (let i = 0; i < 3; i++) {
      const x = slotStartX + i * slotGap;

      const bg = this.add.rectangle(x, slotY, 58, 58, 0x0b0f14, 0.72).setStrokeStyle(2, 0x5b6375, 1);
      const orb = this.add.circle(x, slotY, 15, 0xffffff, 0.9).setStrokeStyle(2, 0xffffff, 0.25);
      const num = this.add.text(x - 22, slotY - 24, String(i + 1), { fontSize: "11px", color: "#d8e2f2" });
      const name = this.add.text(x, slotY + 26, "", { fontSize: "9px", color: "#cbd5e1" }).setOrigin(0.5, 0);
      const cd = this.add.graphics().setDepth(1110);
      root.add([bg, orb, num, name, cd]);

      slots.push({ bg, orb, num, name, cd, spellId: null });
    }

    // Subtitle box using Spell_sub_box
    let subBox = null;
    if (this.textures.exists("ui-sub")) {
      subBox = this.add.image(320, 392, "ui-sub").setOrigin(0.5, 1).setScale(0.77);
      root.add(subBox);
    }
    const subtitleText = this.add.text(60, 356, "", { fontSize: "11px", color: "#e8eef7", wordWrap: { width: 520 } });
    root.add(subtitleText);

    // Mic hint
    const micText = this.add.text(520, 356, "🎙 OFF", { fontSize: "11px", color: "#e8eef7" });
    root.add(micText);

    this.ui = {
      root,
      roomText, phaseText,
      hpNameL, hpNameR,
      hpFillL, hpFillR,
      manaFill, manaText,
      subtitleText,
      micText,
      slots,
      lastSubtitleAt: 0,
    };

    // Apply equipped spells to slots
    this.refreshSpellSlots();
  }

  refreshSpellSlots() {
    if (!this.ui?.slots) return;
    const lo = Array.from(this.equipped || []).slice(0, 3);
    for (let i = 0; i < this.ui.slots.length; i++) {
      const slot = this.ui.slots[i];
      const sid = lo[i] || null;
      slot.spellId = sid;
      slot.name.setText(sid ? sid.replace(/_/g, " ") : "");
      const meta = sid ? this.spellData?.[sid] : null;
      const col = Number.isFinite(meta?.color) ? meta.color : 0xffffff;
      slot.orb.setFillStyle(col, 0.9);
      slot.orb.setStrokeStyle(2, 0xffffff, 0.22);
      slot.cd.clear();
    }
  }

  updateHudFromPlayers(playersArr) {
    if (!this.ui) return;
    const me = playersArr.find(p => p.id === this.playerId);
    const other = playersArr.find(p => p.id !== this.playerId);

    this.ui.hpNameL.setText(me ? `${me.name}: ${me.hp}` : "");
    this.ui.hpNameR.setText(other ? `${other.name}: ${other.hp}` : "");

    const setBar = (rect, pct, col) => {
      const w = 188;
      rect.width = clamp(w * pct, 0, w);
      rect.fillColor = col;
    };

    const hpL = clamp((me?.hp ?? 0) / 100, 0, 1);
    const hpR = clamp((other?.hp ?? 0) / 100, 0, 1);
    const colL = (me?.hp ?? 0) > 50 ? 0x4ade80 : (me?.hp ?? 0) > 25 ? 0xfbbf24 : 0xef4444;
    const colR = (other?.hp ?? 0) > 50 ? 0xfb923c : (other?.hp ?? 0) > 25 ? 0xfbbf24 : 0xef4444;
    setBar(this.ui.hpFillL, hpL, colL);
    // Right bar anchored on right
    this.ui.hpFillR.width = clamp(188 * hpR, 0, 188);
    this.ui.hpFillR.fillColor = colR;

    // Phase text
    this.ui.phaseText.setText(`Phase: ${this.phase}`);
  }

  setSubtitle(s) {
    if (!this.ui?.subtitleText) return;
    this.ui.subtitleText.setText(String(s || ""));
    this.ui.lastSubtitleAt = Date.now();
  }

  // ───────────────────────── Game Over Overlay ─────────────────────────
  initGameOverOverlay() {
    const root = this.add.container(0, 0).setDepth(1300).setScrollFactor(0);
    root.setVisible(false);

    // Dark scrim
    const scrim = this.add.rectangle(320, 200, 640, 400, 0x000000, 0.65);
    root.add(scrim);

    // Panel (drive basic_ui)
    let panel = null;
    if (this.textures.exists("ui-basic")) {
      panel = this.add.image(320, 200, "ui-basic").setScale(0.7);
      root.add(panel);
    }

    const title = this.add.text(320, 150, "DEFEAT", { fontSize: "26px", color: "#ff7b7b" }).setOrigin(0.5);
    const hint = this.add.text(320, 205, "Press N to Rematch", { fontSize: "12px", color: "#e8eef7" }).setOrigin(0.5);
    const hint2 = this.add.text(320, 228, "Press B to Back to Lobby", { fontSize: "12px", color: "#e8eef7" }).setOrigin(0.5);

    // Clickable buttons
    const btnRematch = this.add.rectangle(320, 270, 220, 44, 0x162031, 0.9).setStrokeStyle(2, 0x6ee7ff, 0.6).setInteractive({ useHandCursor: true });
    const btnBack = this.add.rectangle(320, 325, 220, 44, 0x162031, 0.9).setStrokeStyle(2, 0xffb86e, 0.6).setInteractive({ useHandCursor: true });
    const t1 = this.add.text(320, 270, "Rematch", { fontSize: "14px", color: "#e8eef7" }).setOrigin(0.5);
    const t2 = this.add.text(320, 325, "Back", { fontSize: "14px", color: "#e8eef7" }).setOrigin(0.5);

    btnRematch.on("pointerdown", () => getSocket().emit("room:rematch"));
    btnBack.on("pointerdown", () => { localStorage.removeItem("wizardSession"); location.reload(); });

    root.add([title, hint, hint2, btnRematch, btnBack, t1, t2]);

    this.gameOver = { root, title, hint, hint2 };
  }

  showGameOver(winnerId) {
    if (!this.gameOver?.root) return;
    const isWin = winnerId === this.playerId;
    this.gameOver.title.setText(isWin ? "VICTORY" : "DEFEAT");
    this.gameOver.title.setColor(isWin ? "#6ee7ff" : "#ff7b7b");
    this.gameOver.root.setVisible(true);
    this.gameOver.shown = true;
  }

  hideGameOver() {
    if (this.gameOver?.root) this.gameOver.root.setVisible(false);
    if (this.gameOver) this.gameOver.shown = false;
  }

  // ───────────────────────── Players ─────────────────────────
  updatePlayers(playersArr) {
    for (const p of playersArr) {
      if (!this.playersById.has(p.id)) {
        const pIdx = playersArr.indexOf(p);
        const texKey = pIdx === 0 ? "wizard-red" : "wizard-blue";
        const animKey = pIdx === 0 ? "wiz-red-idle" : "wiz-blue-idle";

        let sprite;
        if (this.textures.exists(texKey)) {
          sprite = this.physics.add.sprite(p.x, p.y, texKey);
          sprite.play(animKey);
          sprite.setScale(1.0);
        } else {
          const key = `wiz_${p.id}`;
          if (!this.textures.exists(key)) {
            const g = this.make.graphics({ add: false });
            g.fillStyle(0x6ee7ff); g.fillRect(0, 0, 28, 28);
            g.generateTexture(key, 28, 28); g.destroy();
          }
          sprite = this.physics.add.sprite(p.x, p.y, key).setDisplaySize(28, 28);
        }

        sprite.setCollideWorldBounds(true);
        sprite.body.setAllowGravity(false);

        const label = this.add.text(p.x, p.y - 48, p.name || "?", {
          fontSize: "11px",
          color: p.id === this.playerId ? "#6ee7ff" : "#ffb86e",
          align: "center",
          stroke: "#000",
          strokeThickness: 2,
        }).setOrigin(0.5);

        this.playersById.set(p.id, { ...p, sprite, label });
      }

      const obj = this.playersById.get(p.id);
      obj.name = p.name; obj.ready = p.ready; obj.hp = p.hp;
      if (p.id !== this.playerId) obj.sprite.setPosition(p.x, p.y);
      if (obj.label) { obj.label.setPosition(obj.sprite.x, obj.sprite.y - 48); obj.label.setText(p.name || "?"); }

      // Face opponent
      const opponent = playersArr.find(pp => pp.id !== p.id);
      if (opponent) obj.sprite.setFlipX(opponent.x < p.x);
    }

    const ids = new Set(playersArr.map(p => p.id));
    for (const [id, obj] of this.playersById.entries()) {
      if (!ids.has(id)) {
        obj.sprite.destroy(); obj.label?.destroy();
        this.playersById.delete(id);
      }
    }
  }

  serverNow() { return Date.now() + this.clockOffsetMs; }

  update(time, delta) {
    // Phase timer
    if (this.ui?.phaseText) this.ui.phaseText.setText(`Phase: ${this.phase}`);
    if (this.phaseEndTime && this.ui?.roomText) {
      const ms = Math.max(0, this.phaseEndTime - this.serverNow());
      this.ui.roomText.setText(`Room: ${this.roomCode} · ⏱ ${(ms / 1000).toFixed(1)}s`);
    } else if (this.ui?.roomText) {
      this.ui.roomText.setText(`Room: ${this.roomCode}`);
    }

    // Mana regen (client-predicted)
    if (this.phase === PHASE.ROUND || this.phase === PHASE.PREROUND) {
      this.mana = Math.min(MAX_MANA, this.mana + MANA_REGEN_PER_SEC * (delta / 1000));
    }
    if (this.ui?.manaFill) this.ui.manaFill.width = clamp(188 * (this.mana / MAX_MANA), 0, 188);
    if (this.ui?.manaText) this.ui.manaText.setText(`MP ${Math.floor(this.mana)}`);

    // Update cooldown masks
    this.updateCooldownMasks();

    // Toggle ready
    if (this.keyR && Phaser.Input.Keyboard.JustDown(this.keyR)) {
      const me = this.playersById.get(this.playerId);
      getSocket().emit("player:ready", { ready: !(me?.ready) });
    }

    // Toggle mic
    if (this.keyM && Phaser.Input.Keyboard.JustDown(this.keyM)) {
      this.micOn = !this.micOn;
      if (this.micOn) {
        if (!this.voice.supported) {
          this.micOn = false;
          this.setSubtitle("Mic unsupported: use Chrome/Edge.");
          this.ui?.micText?.setText("🎙 UNSUPPORTED");
        } else {
          this.voice.start();
          this.setSubtitle("🎙 Listening… say a spell incantation");
          this.ui?.micText?.setText("🎙 ON");
        }
      } else {
        this.voice.stop();
        this.setSubtitle("🎙 OFF");
        this.ui?.micText?.setText("🎙 OFF");
      }
    }

    // End phase keys
    if (this.keyN && Phaser.Input.Keyboard.JustDown(this.keyN) && this.phase === PHASE.END) getSocket().emit("room:rematch");
    if (this.keyB && Phaser.Input.Keyboard.JustDown(this.keyB) && this.phase === PHASE.END) { localStorage.removeItem("wizardSession"); location.reload(); }

    // Keyboard casting
    const slots = this.ui?.slots || [];
    if (this.key1 && Phaser.Input.Keyboard.JustDown(this.key1) && slots[0]?.spellId) this.castSpell(slots[0].spellId);
    if (this.key2 && Phaser.Input.Keyboard.JustDown(this.key2) && slots[1]?.spellId) this.castSpell(slots[1].spellId);
    if (this.key3 && Phaser.Input.Keyboard.JustDown(this.key3) && slots[2]?.spellId) this.castSpell(slots[2].spellId);

    // Movement
    const me = this.playersById.get(this.playerId);
    if (!me) return;
    if (me.label) me.label.setPosition(me.sprite.x, me.sprite.y - 48);

    if (this.phase !== PHASE.ROUND) { me.sprite.setVelocity(0, 0); return; }

    const speed = 200;
    let vx = 0, vy = 0;
    if (this.cursors?.left?.isDown) vx -= speed;
    if (this.cursors?.right?.isDown) vx += speed;
    if (this.cursors?.up?.isDown) vy -= speed;
    if (this.cursors?.down?.isDown) vy += speed;
    me.sprite.setVelocity(vx, vy);
  }

  updateCooldownMasks() {
    if (!this.ui?.slots) return;
    const now = Date.now();

    for (let i = 0; i < this.ui.slots.length; i++) {
      const slot = this.ui.slots[i];
      slot.cd.clear();

      if (!slot.spellId) continue;
      const spell = this.spellData?.[slot.spellId];
      const cdMs = (Number(spell?.cooldown ?? 0)) * 1000;
      const last = this.lastCastTime[slot.spellId] || 0;
      const remaining = Math.max(0, cdMs - (now - last));
      const ratio = cdMs > 0 ? (remaining / cdMs) : 0;

      // Mana gating tint
      const manaOk = this.mana >= (Number(spell?.manaCost ?? 0));
      slot.bg.setAlpha(manaOk ? 0.72 : 0.45);
      slot.orb.setAlpha(manaOk ? 0.9 : 0.45);

      if (ratio <= 0) continue;

      // Cooldown pie mask (clockwise)
      const r = 28;
      const cx = slot.bg.x;
      const cy = slot.bg.y;
      slot.cd.fillStyle(0x000000, 0.55);
      slot.cd.beginPath();
      slot.cd.moveTo(cx, cy);
      slot.cd.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * ratio, false);
      slot.cd.closePath();
      slot.cd.fillPath();

      // remaining text
      slot.cd.lineStyle(1, 0xffffff, 0.08);
      slot.cd.strokeCircle(cx, cy, r);
    }
  }

  sendPoseIfNeeded() {
    if (this.phase !== PHASE.ROUND) return;
    const me = this.playersById.get(this.playerId);
    if (!me) return;
    getSocket().emit("player:pose", { x: me.sprite.x, y: me.sprite.y });
  }

  // ─── Voice ───
  buildKeywordIndex(kw) {
    this.keywordToSpell.clear();
    for (const [sid, obj] of Object.entries(kw)) {
      for (const s of [obj.incantation, ...(obj.aliases || [])].filter(Boolean)) {
        this.keywordToSpell.set(s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim(), sid);
      }
    }
  }

  levenshtein(a, b) {
    a = String(a || ""); b = String(b || "");
    const n = a.length, m = b.length;
    if (!n) return m; if (!m) return n;
    const dp = Array.from({ length: m + 1 }, (_, j) => j);
    for (let i = 1; i <= n; i++) {
      let prev = dp[0]; dp[0] = i;
      for (let j = 1; j <= m; j++) {
        const tmp = dp[j];
        dp[j] = Math.min(dp[j] + 1, dp[j-1] + 1, prev + (a[i-1] === b[j-1] ? 0 : 1));
        prev = tmp;
      }
    }
    return dp[m];
  }

  similarity(a, b) {
    a = String(a || ""); b = String(b || "");
    return 1 - this.levenshtein(a, b) / (Math.max(a.length, b.length) || 1);
  }

  bestSpellsForPhrase(normalized, topK = 3) {
    const scores = new Map();
    for (const [k, sid] of this.keywordToSpell.entries()) {
      const s = this.similarity(normalized, k);
      if (s > (scores.get(sid) ?? 0)) scores.set(sid, s);
    }
    return [...scores.entries()].map(([spellId, score]) => ({ spellId, score })).sort((a, b) => b.score - a.score).slice(0, topK);
  }

  onVoicePhrase(raw, normalized) {
    const exact = this.keywordToSpell.get(normalized);
    if (exact) { this.setSubtitle(`🗣 "${raw}" → ${exact}`); this.castSpell(exact); return; }
    const top = this.bestSpellsForPhrase(normalized, 3);
    const best = top[0];
    if (best?.score >= 0.78) { this.setSubtitle(`🗣 "${raw}" → ${best.spellId} (${(best.score*100)|0}%)`); this.castSpell(best.spellId); return; }
    const shown = top.filter(x => x.score >= 0.55);
    let msg = `🗣 "${raw}" → no match`;
    if (shown.length) msg += `\nMaybe: ${shown.map(x => `${x.spellId}(${(x.score*100)|0}%)`).join(", ")}`;
    this.setSubtitle(msg);
  }

  castSpell(spellId) {
    if (this.equipped && !this.equipped.has(spellId)) return;
    if (![PHASE.PREROUND, PHASE.ROUND].includes(this.phase)) return;
    const me = this.playersById.get(this.playerId);
    if (!me) return;

    // Client-side cooldown check
    const spell = this.spellData[spellId];
    const cdMs = (Number(spell?.cooldown ?? 0)) * 1000;
    const now = Date.now();
    if (now - (this.lastCastTime[spellId] || 0) < cdMs) return;

    // Mana check
    const cost = Number(spell?.manaCost ?? 0);
    if (this.mana < cost) {
      this.setSubtitle(`Not enough mana for ${spellId} (need ${cost}, have ${Math.floor(this.mana)})`);
      makeBeep(this.audioCtx, 200, 0.15, 0.06, "square");
      return;
    }
    this.mana -= cost;
    this.lastCastTime[spellId] = now;

    // Aim at opponent (simple)
    const others = [...this.playersById.values()].filter(p => p.id !== this.playerId);
    let ax = 1, ay = 0;
    if (others.length) {
      const o = others[0].sprite;
      const dx = o.x - me.sprite.x, dy = o.y - me.sprite.y;
      const len = Math.hypot(dx, dy) || 1;
      ax = dx / len; ay = dy / len;
    }

    getSocket().emit("spell:cast", { spellId, aimDir: { x: ax, y: ay } });
  }

  spawnSpell(evt) {
    const caster = this.playersById.get(evt.casterId);
    if (!caster) return;

    const spellId = String(evt.spellId || "").toLowerCase();
    const { kind, behavior, color } = getSpellMeta(this, spellId);
    const tint = (color ?? 0xffffff);

    const delayMs = Math.max(0, Number(evt.delayMs ?? 0));
    if (delayMs > 0 && (kind === "projectile" || kind === "status")) {
      // Charge-up VFX
      const ring = this.add.circle(caster.sprite.x, caster.sprite.y - 40, 10, tint, 0.12).setStrokeStyle(2, tint, 0.6).setDepth(900);
      this.tweens.add({ targets: ring, scale: 2.6, alpha: 0, duration: Math.min(900, delayMs), ease: "Quad.easeOut" });
      this.time.delayedCall(delayMs, () => { ring.destroy(); this.spawnSpell({ ...evt, delayMs: 0 }); });
      return;
    }

    // Shield
    if (kind === "shield") {
      const key = `_shield_tex`;
      if (!this.textures.exists(key)) {
        const g = this.make.graphics({ add: false });
        g.lineStyle(2, tint, 0.65);
        g.strokeCircle(30, 30, 28);
        g.fillStyle(tint, 0.18);
        g.fillCircle(30, 30, 28);
        g.generateTexture(key, 60, 60); g.destroy();
      }
      const bubble = this.add.sprite(caster.sprite.x, caster.sprite.y, key).setDepth(850);
      this.time.delayedCall(Number(behavior.lifetimeMs ?? 3000), () => bubble?.destroy());
      return;
    }

    // Heal
    if (kind === "heal") {
      this.spawnHealBurst(caster.sprite.x, caster.sprite.y, tint, Number(this.spellData?.[spellId]?.heal ?? 10));
      return;
    }

    // Block (visual wall)
    if (kind === "block") {
      const dir = evt.aimDir || { x: 1, y: 0 };
      const d = 54;
      const wx = caster.sprite.x + dir.x * d;
      const wy = caster.sprite.y + dir.y * d;
      const w = 18, h = 58;
      const key = `_wall_${spellId}`;
      if (!this.textures.exists(key)) {
        const g = this.make.graphics({ add: false });
        g.fillStyle(tint, 0.7);
        g.fillRoundedRect(0, 0, w, h, 5);
        g.lineStyle(2, 0xffffff, 0.25);
        g.strokeRoundedRect(0, 0, w, h, 5);
        g.generateTexture(key, w, h);
        g.destroy();
      }
      const wall = this.add.sprite(wx, wy, key).setDepth(820);
      wall.setRotation(Math.atan2(dir.y, dir.x) + Math.PI / 2);
      this.time.delayedCall(Number(behavior.blockMs ?? 2500), () => wall?.destroy());
      return;
    }

    // Status: quick cast aura (damage handled server-side)
    if (kind === "status") {
      const aura = this.add.circle(caster.sprite.x, caster.sprite.y - 40, 18, tint, 0.10).setStrokeStyle(2, tint, 0.45).setDepth(900);
      this.tweens.add({ targets: aura, scale: 3.6, alpha: 0, duration: 520, ease: "Cubic.easeOut", onComplete: () => aura.destroy() });

      // If it's gas, hint at a direction cloud (actual cloud spawns on hit)
      if (spellId === "gas_condensation") {
        const dir = evt.aimDir || { x: 1, y: 0 };
        const px = caster.sprite.x + dir.x * 120;
        const py = caster.sprite.y + dir.y * 40;
        this.spawnImpactBurst(px, py, tint, 2);
      }
      return;
    }

    // Projectile
    const fallbackBeh = SPELL_BEHAVIOR_FALLBACK[spellId] ?? SPELL_BEHAVIOR_FALLBACK.spark;
    const beh = {
      speed: Number(behavior.speed ?? fallbackBeh.speed ?? 520),
      lifetimeMs: Number(behavior.lifetimeMs ?? fallbackBeh.lifetimeMs ?? 800),
      radius: Number(behavior.radius ?? fallbackBeh.radius ?? 6),
      count: Number(behavior.count ?? fallbackBeh.count ?? 1),
      spreadDeg: Number(behavior.spreadDeg ?? fallbackBeh.spreadDeg ?? 0),
    };

    const seed = evt.seed ?? 1;
    const rnd = prng(seed);
    const baseAngle = Math.atan2(evt.aimDir?.y ?? 0, evt.aimDir?.x ?? 1);

    const projTexMap = {
      spark: "proj-spark",
      wagalona: "proj-wagalona",
      zephyra: "proj-zephyra",
    };

    for (let i = 0; i < (beh.count || 1); i++) {
      const spread = Phaser.Math.DegToRad((beh.spreadDeg || 0) * ((i - (beh.count - 1) / 2)));
      const jitter = (rnd() - 0.5) * Phaser.Math.DegToRad((beh.spreadDeg || 0) * 0.35);
      const ang = baseAngle + spread + jitter;
      const vx = Math.cos(ang) * beh.speed;
      const vy = Math.sin(ang) * beh.speed;

      let proj;
      const texKey = projTexMap[spellId];
      if (texKey && this.textures.exists(texKey)) {
        proj = this.physics.add.sprite(caster.sprite.x, caster.sprite.y, texKey);
        const scale = (beh.radius || 6) / 16;
        proj.setScale(scale);
      } else {
        const r = beh.radius || 6;
        const key = `proj_${spellId}_${r}_${tint}`;
        if (!this.textures.exists(key)) {
          const g = this.make.graphics({ add: false });
          g.fillStyle(tint, 1.0);
          g.fillCircle(r, r, r);
          g.lineStyle(2, 0xffffff, 0.18);
          g.strokeCircle(r, r, r);
          g.generateTexture(key, r * 2, r * 2);
          g.destroy();
        }
        proj = this.physics.add.sprite(caster.sprite.x, caster.sprite.y, key);
      }

      proj.body.setAllowGravity(false);
      proj.setVelocity(vx, vy);
      proj.setDepth(780);
      this.projectiles.add(proj);

      // Tiny trail (particle follow)
      if (this.vfx?.manager) {
        const trail = this.vfx.manager.createEmitter({
          follow: proj,
          frequency: 50,
          lifespan: { min: 120, max: 240 },
          speed: { min: 0, max: 18 },
          scale: { start: 1.6, end: 0 },
          alpha: { start: 0.22, end: 0 },
          tint,
          blendMode: "ADD",
        });
        this.time.delayedCall(beh.lifetimeMs, () => {
          trail.stop();
          this.time.delayedCall(400, () => { try { this.vfx.manager.removeEmitter(trail); } catch {} });
        });
      }

      this.time.delayedCall(beh.lifetimeMs, () => { if (proj?.active) proj.destroy(); });
    }
  }
}
