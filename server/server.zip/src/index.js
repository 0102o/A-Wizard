import express from "express";
import http from "http";
import { Server } from "socket.io";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT ? Number(process.env.PORT) : 3001;

const PHASE = Object.freeze({ LOBBY: "LOBBY", PREROUND: "PREROUND", ROUND: "ROUND", END: "END" });
const MAX_MANA = 100;
const MANA_REGEN_PER_SEC = 12;

function nowMs() { return Date.now(); }
function cryptoRandomToken() { return Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2); }
function makeRoomCode() {
  const c = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = ""; for (let i = 0; i < 5; i++) code += c[Math.floor(Math.random() * c.length)];
  return code;
}
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function angleBetween(ax, ay, bx, by) {
  const dot = ax*bx + ay*by;
  const la = Math.hypot(ax, ay) || 1, lb = Math.hypot(bx, by) || 1;
  return Math.acos(clamp(dot / (la * lb), -1, 1));
}

function normalizeDir(d) {
  const x = Number(d?.x ?? 1), y = Number(d?.y ?? 0);
  const len = Math.hypot(x, y) || 1;
  return { x: x/len, y: y/len };
}

function loadSpells() {
  const p = path.join(__dirname, "..", "data", "spells.json");
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}

const SPELLS = loadSpells();
const rooms = new Map();

function getRoom(code) { return rooms.get(code) ?? null; }

function emptyRoomState(room) {
  return {
    roomCode: room.roomCode, phase: room.phase, phaseEndTime: room.phaseEndTime,
    players: Array.from(room.players.values()).map(p => ({
      id: p.id, name: p.name, ready: p.ready, x: p.x, y: p.y, hp: p.hp,
    })),
  };
}

function broadcastRoom(io, room) { io.to(room.roomCode).emit("room:state", emptyRoomState(room)); }

function setPhase(io, room, phase, durationMs = null) {
  room.phase = phase;
  const serverTime = nowMs();
  room.phaseEndTime = durationMs ? (serverTime + durationMs) : null;
  io.to(room.roomCode).emit("phase:start", { phase, durationMs, serverTime });
  broadcastRoom(io, room);
}

function clearPhaseTimer(room) {
  if (room.timers.phase) { clearTimeout(room.timers.phase); room.timers.phase = null; }
}

function broadcastMatchEnd(io, room, winnerId) {
  setPhase(io, room, PHASE.END, null);
  io.to(room.roomCode).emit("match:end", { winnerId });
}

function resetForRematch(room) {
  const ids = [...room.players.keys()];
  for (let i = 0; i < ids.length; i++) {
    const p = room.players.get(ids[i]);
    if (!p) continue;
    p.hp = 100; p.mana = MAX_MANA; p.ready = true;
    p.x = i === 0 ? 160 : 480; p.y = 320;
    p.lastCastAt = {}; p.shieldUntil = 0; p.shieldBlocks = 0; p.blockUntil = 0; p.blockBlocks = 0; p.statuses = {};
  }
}

function createRoom(hostSocket, name) {
  let code = makeRoomCode();
  while (rooms.has(code)) code = makeRoomCode();
  const room = { roomCode: code, phase: PHASE.LOBBY, phaseEndTime: null, players: new Map(), timers: { phase: null, mana: null } };
  rooms.set(code, room);
  joinRoom(room, hostSocket, name);
  return room;
}

function joinRoom(room, socket, name) {
  if (room.players.size >= 2) throw new Error("Room is full (max 2 players).");
  const spawnX = room.players.size === 0 ? 160 : 480;
  room.players.set(socket.id, {
    id: socket.id, token: cryptoRandomToken(),
    name: (name && String(name).trim()) ? String(name).trim().slice(0, 16) : "Wizard",
    ready: false, x: spawnX, y: 320, hp: 100, mana: MAX_MANA,
    lastCastAt: {}, shieldUntil: 0, shieldBlocks: 0, blockUntil: 0, blockBlocks: 0, statuses: {},
  });
  socket.join(room.roomCode);
}

function maybeStartMatch(io, room) {
  if (room.phase !== PHASE.LOBBY || room.players.size !== 2) return;
  if (![...room.players.values()].every(p => p.ready)) return;
  clearPhaseTimer(room);
  setPhase(io, room, PHASE.PREROUND, 15000);
  room.timers.phase = setTimeout(() => {
    setPhase(io, room, PHASE.ROUND, null);
    // Start mana regen tick
    startManaRegen(io, room);
  }, 15000);
}

function startManaRegen(io, room) {
  if (room.timers.mana) clearInterval(room.timers.mana);
  room.timers.mana = setInterval(() => {
    if (room.phase !== PHASE.ROUND && room.phase !== PHASE.PREROUND) {
      clearInterval(room.timers.mana); room.timers.mana = null; return;
    }
    for (const p of room.players.values()) {
      p.mana = Math.min(MAX_MANA, p.mana + MANA_REGEN_PER_SEC * 0.1); // 100ms tick
    }
  }, 100);
}

function canCast(player, spellId) {
  const spell = SPELLS[spellId];
  if (!spell) return { ok: false, reason: "Unknown spell" };
  const cdMs = Math.max(0, Number(spell.cooldown ?? 0)) * 1000;
  const last = player.lastCastAt[spellId] ?? 0;
  const t = nowMs();
  if (t - last < cdMs) return { ok: false, reason: "Cooldown" };
  const cost = Number(spell.manaCost ?? 0);
  if (player.mana < cost) return { ok: false, reason: "No mana" };
  player.mana -= cost;
  player.lastCastAt[spellId] = t;
  return { ok: true, spell };
}

const app = express();
const httpServer = http.createServer(app);
const io = new Server(httpServer, { cors: { origin: "*" } });


function hasActiveShield(p) { return (p.shieldUntil ?? 0) > nowMs() && (p.shieldBlocks ?? 0) > 0; }
function hasActiveBlock(p) { return (p.blockUntil ?? 0) > nowMs() && (p.blockBlocks ?? 0) > 0; }

function consumeDefense(p) {
  if (hasActiveShield(p)) { p.shieldBlocks -= 1; if (p.shieldBlocks <= 0) p.shieldUntil = 0; return "shield"; }
  if (hasActiveBlock(p)) { p.blockBlocks -= 1; if (p.blockBlocks <= 0) p.blockUntil = 0; return "block"; }
  return null;
}

function applyHit(io, room, { caster, target, spellId, damage, tickIndex = 0 }) {
  const blockedBy = consumeDefense(target);
  if (blockedBy) {
    io.to(room.roomCode).emit("hit:event", { casterId: caster.id, targetId: target.id, spellId, damage: 0, blocked: true, blockedBy, tickIndex, serverTime: nowMs() });
    return { blocked: true, killed: false };
  }

  const d = Math.max(0, Number(damage ?? 0));
  target.hp = clamp(target.hp - d, 0, 100);
  io.to(room.roomCode).emit("hit:event", { casterId: caster.id, targetId: target.id, spellId, damage: d, blocked: false, tickIndex, targetHp: target.hp, serverTime: nowMs() });

  if (target.hp <= 0) {
    setPhase(io, room, PHASE.END, 8000);
    io.to(room.roomCode).emit("round:end", { winnerId: caster.id, serverTime: nowMs() });
    return { blocked: false, killed: true };
  }
  return { blocked: false, killed: false };
}

function scheduleTicks(io, room, { casterId, targetId, spellId, hits, intervalMs, damage, stunMs = 0 }) {
  const total = Math.max(0, Number(hits ?? 0));
  const dt = Math.max(0, Number(intervalMs ?? 0));
  if (total <= 1 || dt <= 0) return;

  for (let i = 1; i < total; i++) {
    setTimeout(() => {
      // Room/players might be gone
      if (!rooms.has(room.roomCode)) return;
      const r = rooms.get(room.roomCode);
      if (!r || r.phase === PHASE.END) return;
      const caster = r.players.get(casterId);
      const target = r.players.get(targetId);
      if (!caster || !target || target.hp <= 0) return;

      if (stunMs > 0 && i === 1) {
        target.stunnedUntil = Math.max(target.stunnedUntil ?? 0, nowMs() + stunMs);
        io.to(r.roomCode).emit("status:event", { casterId, targetId, spellId, type: "stun", ms: stunMs, serverTime: nowMs() });
      }

      applyHit(io, r, { caster, target, spellId, damage, tickIndex: i });
      broadcastRoom(io, r);
    }, i * dt);
  }
}

io.on("connection", (socket) => {
  socket.on("room:create", ({ name } = {}) => {
    try {
      const room = createRoom(socket, name);
      socket.emit("room:joined", { roomCode: room.roomCode, playerId: socket.id, reconnectToken: room.players.get(socket.id)?.token });
      broadcastRoom(io, room);
    } catch (e) { socket.emit("room:error", { reason: String(e.message || e) }); }
  });

  socket.on("room:join", ({ roomCode, name } = {}) => {
    try {
      const code = String(roomCode || "").trim().toUpperCase();
      const room = getRoom(code);
      if (!room) throw new Error("Room not found.");
      joinRoom(room, socket, name);
      socket.emit("room:joined", { roomCode: room.roomCode, playerId: socket.id, reconnectToken: room.players.get(socket.id)?.token });
      broadcastRoom(io, room);
    } catch (e) { socket.emit("room:error", { reason: String(e.message || e) }); }
  });

  socket.on("room:reconnect", ({ roomCode, reconnectToken, name } = {}) => {
    try {
      const room = getRoom(String(roomCode || "").trim().toUpperCase());
      if (!room) throw new Error("Room not found.");
      const existing = [...room.players.values()].find(p => p.token === String(reconnectToken || "").trim());
      if (!existing) throw new Error("Reconnect token invalid.");
      room.players.delete(existing.id);
      existing.id = socket.id;
      if (name && String(name).trim()) existing.name = String(name).trim().slice(0, 16);
      room.players.set(socket.id, existing);
      socket.join(room.roomCode);
      socket.emit("room:joined", { roomCode: room.roomCode, playerId: socket.id, reconnectToken: existing.token });
      broadcastRoom(io, room);
    } catch (e) { socket.emit("room:error", { reason: String(e.message || e) }); }
  });

  socket.on("player:ready", ({ ready } = {}) => {
    const roomCode = [...socket.rooms].find(r => r !== socket.id);
    if (!roomCode) return;
    const room = getRoom(roomCode);
    if (!room) return;
    const player = room.players.get(socket.id);
    if (!player) return;

    // If stunned, ignore movement updates
    if ((player.stunnedUntil ?? 0) > nowMs()) return;
    player.ready = !!ready;
    broadcastRoom(io, room);
    maybeStartMatch(io, room);
  });

  socket.on("player:pose", ({ x, y } = {}) => {
    const roomCode = [...socket.rooms].find(r => r !== socket.id);
    if (!roomCode) return;
    const room = getRoom(roomCode);
    if (!room || room.phase !== PHASE.ROUND) return;
    const player = room.players.get(socket.id);
    if (!player) return;
    player.x = clamp(Number(x ?? player.x), 40, 600);
    player.y = clamp(Number(y ?? player.y), 80, 360);
  });

  socket.on("spell:cast", ({ spellId, aimDir } = {}) => {
    const roomCode = [...socket.rooms].find(r => r !== socket.id);
    if (!roomCode) return;
    const room = getRoom(roomCode);
    if (!room || ![PHASE.PREROUND, PHASE.ROUND].includes(room.phase)) return;
    const caster = room.players.get(socket.id);
    if (!caster) return;

    const sid = String(spellId || "").trim().toLowerCase();
    const { ok, spell } = canCast(caster, sid);
    if (!ok) return;

    const seed = Math.floor(Math.random() * 2**31);
    const dir = normalizeDir(aimDir);

    // Kind-based non-projectile spells
    const kind = String(spell.kind || (sid === "shieldra" ? "shield" : "projectile")).toLowerCase();
    const beh = spell.behavior || {};

    if (kind === "shield") {
      const dur = Math.max(0, Number(beh.lifetimeMs ?? 3000));
      caster.shieldUntil = nowMs() + dur;
      caster.shieldBlocks = Math.max(1, Number(beh.blocks ?? 1));
      io.to(room.roomCode).emit("spell:event", { casterId: socket.id, spellId: sid, aimDir: dir, seed, serverTime: nowMs(), delayMs: Math.max(0, Number(spell?.delayMs ?? 0)) });
      broadcastRoom(io, room);
      return;
    }

    if (kind === "heal") {
      const amt = Math.max(0, Number(spell.heal ?? 0));
      caster.hp = clamp(caster.hp + amt, 0, 100);
      io.to(room.roomCode).emit("spell:event", { casterId: socket.id, spellId: sid, aimDir: dir, seed, serverTime: nowMs(), delayMs: Math.max(0, Number(spell?.delayMs ?? 0)) });
      io.to(room.roomCode).emit("heal:event", { casterId: caster.id, spellId: sid, heal: amt, casterHp: caster.hp, serverTime: nowMs() });
      broadcastRoom(io, room);
      return;
    }

    if (kind === "block") {
      const dur = Math.max(0, Number(beh.blockMs ?? 2500));
      caster.blockUntil = nowMs() + dur;
      caster.blockBlocks = Math.max(1, Number(beh.blocks ?? 1));
      io.to(room.roomCode).emit("spell:event", { casterId: socket.id, spellId: sid, aimDir: dir, seed, serverTime: nowMs(), delayMs: Math.max(0, Number(spell?.delayMs ?? 0)) });
      broadcastRoom(io, room);
      return;
    }
    io.to(room.roomCode).emit("spell:event", { casterId: socket.id, spellId: sid, aimDir: dir, seed, serverTime: nowMs(), delayMs: Math.max(0, Number(spell?.delayMs ?? 0)) });

    // Targeting + hit resolution (server-authoritative)
    if (room.players.size !== 2) return;
    const target = [...room.players.values()].find(p => p.id !== caster.id);
    if (!target) return;

    const resolve = () => {
      // Room/players might be gone
      const roomNow = getRoom(room.roomCode);
      if (!roomNow || roomNow.phase === PHASE.END) return;
      const casterNow = roomNow.players.get(caster.id);
      const targetNow = roomNow.players.get(target.id);
      if (!casterNow || !targetNow || targetNow.hp <= 0) return;

      const dx = targetNow.x - casterNow.x, dy = targetNow.y - casterNow.y;
      const dist = Math.hypot(dx, dy);

      const beh2 = spell?.behavior || {};
      const maxRange = Number(beh2.range ?? 560);
      if (dist > maxRange) return;

      const toTarget = { x: dx / (dist || 1), y: dy / (dist || 1) };
      const ang = angleBetween(dir.x, dir.y, toTarget.x, toTarget.y);
      const coneDeg = Number(beh2.coneDeg ?? 24);
      if (ang > (coneDeg * Math.PI / 180)) return;

      const kind2 = String(spell.kind || "projectile").toLowerCase();
      const dmg = Math.max(0, Number(spell?.damage ?? 0));

      if (kind2 === "status") {
        const total = Number(spell.hits ?? spell.ticks ?? 1);
        const dt = Number(spell.tickIntervalMs ?? 500);
        const stun = Number(spell.stunMs ?? 0);

        if (stun > 0) {
          targetNow.stunnedUntil = Math.max(targetNow.stunnedUntil ?? 0, nowMs() + stun);
          io.to(roomNow.roomCode).emit("status:event", { casterId: casterNow.id, targetId: targetNow.id, spellId: sid, type: "stun", ms: stun, serverTime: nowMs() });
        }

        // First tick immediately
        const r1 = applyHit(io, roomNow, { caster: casterNow, target: targetNow, spellId: sid, damage: dmg, tickIndex: 0 });
        broadcastRoom(io, roomNow);
        if (r1.killed) return;

        scheduleTicks(io, roomNow, { casterId: casterNow.id, targetId: targetNow.id, spellId: sid, hits: total, intervalMs: dt, damage: dmg, stunMs: 0 });
        return;
      }

      // projectile: single hit, optional multi-hit followup
      const r0 = applyHit(io, roomNow, { caster: casterNow, target: targetNow, spellId: sid, damage: dmg, tickIndex: 0 });
      broadcastRoom(io, roomNow);
      if (r0.killed) return;

      const total = Number(spell.hits ?? 1);
      const dt = Number(spell.tickIntervalMs ?? 0);
      if (total > 1 && dt > 0) {
        scheduleTicks(io, roomNow, { casterId: casterNow.id, targetId: targetNow.id, spellId: sid, hits: total, intervalMs: dt, damage: dmg, stunMs: 0 });
      }
    };

    const delay = Math.max(0, Number(spell.delayMs ?? 0));
    if (delay > 0) setTimeout(resolve, delay);
    else resolve();


  });

  socket.on("room:rematch", () => {
    const roomCode = [...socket.rooms].find(r => r !== socket.id);
    if (!roomCode) return;
    const room = getRoom(roomCode);
    if (!room || room.phase !== PHASE.END) return;
    resetForRematch(room);
    clearPhaseTimer(room);
    setPhase(io, room, PHASE.PREROUND, 8000);
    room.timers.phase = setTimeout(() => {
      setPhase(io, room, PHASE.ROUND, null);
      startManaRegen(io, room);
    }, 8000);
  });

  socket.on("disconnect", () => {
    for (const room of rooms.values()) {
      if (room.players.has(socket.id)) {
        room.players.delete(socket.id);
        clearPhaseTimer(room);
        if (room.timers.mana) { clearInterval(room.timers.mana); room.timers.mana = null; }
        room.phase = PHASE.LOBBY; room.phaseEndTime = null;
        for (const p of room.players.values()) p.ready = false;
        broadcastRoom(io, room);
        if (room.players.size === 0) rooms.delete(room.roomCode);
        break;
      }
    }
  });
});

app.get("/", (_req, res) => res.send("Wizard Duel server running."));
httpServer.listen(PORT, "0.0.0.0", () => console.log(`[server] http://0.0.0.0:${PORT}`));
